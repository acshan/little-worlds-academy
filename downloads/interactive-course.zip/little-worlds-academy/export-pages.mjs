import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const destination = path.resolve(root, '../deliverables/little-worlds-academy');
// Explicit allowlist: never include the recovered commercial game or local data.
const entries = [
  'index.html', 'style.css', 'app.js', 'course.js', 'labs.js', 'runner.js',
  'server.mjs', 'package.json', 'package-lock.json', 'tests.mjs', 'package.mjs',
  'README.md', 'BUILD-YOUR-OWN.md', 'COURSEBOOK.md', 'DEPLOY-GITHUB.md',
  'project', 'starter', 'downloads',
];
fs.mkdirSync(destination, { recursive: true });
for (const entry of entries) {
  fs.cpSync(path.join(root, entry), path.join(destination, entry), { recursive: true });
}
fs.writeFileSync(path.join(destination, '.nojekyll'), '');
fs.writeFileSync(path.join(destination, '.gitignore'), 'node_modules/\n.DS_Store\n*.log\n');
console.log(`GitHub Pages 发布目录：${destination}`);
